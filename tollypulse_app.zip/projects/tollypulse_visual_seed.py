import os
from supabase import create_client, Client

SUPABASE_URL = "https://qwcoxloagqjmlfzcugen.supabase.co"
SUPABASE_KEY = "sb_publishable_hvT_1U0NpUbueTuf122F_w_wM4pgmVk"

class TollyPulseVisualSeeder:
    def __init__(self):
        self.supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

    def update_posters(self):
        # High quality placeholder posters for top movies
        posters = {
            "Spirit": "https://images.indianexpress.com/2021/10/spirit-1200.jpg",
            "Game Changer": "https://m.media-amazon.com/images/M/MV5BMjA3MjU4NTEtNzYxNi00ZWY3LThmNDgtYmI3ZGI0ZDU3YmRhXkEyXkFqcGc@._V1_.jpg",
            "The Raja Saab": "https://m.media-amazon.com/images/M/MV5BNzQyNjE5MzMtOTk3NS00N2VmLThmNmUtZWRmYWM0ZDA0YjYyXkEyXkFqcGc@._V1_.jpg",
            "SSMB29": "https://stat4.bollywoodhungama.in/wp-content/uploads/2024/01/SSMB29.jpg",
            "Vishwambhara": "https://m.media-amazon.com/images/M/MV5BNzE0YzY3YjUtYmI3MS00ZGYzLTlkZTgtYTMzYjYyZWY0YTAyXkEyXkFqcGc@._V1_.jpg",
            "Pushpa 2: The Rule": "https://m.media-amazon.com/images/M/MV5BNGZlNjdlZmMtYTg0MC00YWZkLThmYjEtYmI3MzcyOTc5MmU2XkEyXkFqcGc@._V1_.jpg",
            "OG": "https://m.media-amazon.com/images/M/MV5BYzA3MjE4NTEtNzYxNi00ZWY3LThmNDgtYmI3ZGI0ZDU3YmRhXkEyXkFqcGc@._V1_.jpg"
        }

        print("🖼️ Syncing movie posters...")
        for title, url in posters.items():
            try:
                self.supabase.table("tollypulse_movies").update({"poster_url": url}).eq("title", title).execute()
                print(f"✅ Poster added: {title}")
            except Exception as e:
                print(f"❌ Error for {title}: {e}")

if __name__ == "__main__":
    seeder = TollyPulseVisualSeeder()
    seeder.update_posters()
