import os
from supabase import create_client, Client

SUPABASE_URL = "https://qwcoxloagqjmlfzcugen.supabase.co"
SUPABASE_KEY = "sb_publishable_hvT_1U0NpUbueTuf122F_w_wM4pgmVk"

class TollyPulseImageFixer:
    def __init__(self):
        self.supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

    def fix_all_images(self):
        # Using more reliable public image sources or placeholders that don't block hotlinking
        posters = {
            "Spirit": "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?q=80&w=300&auto=format&fit=crop",
            "Game Changer": "https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=300&auto=format&fit=crop",
            "The Raja Saab": "https://images.unsplash.com/photo-1536440136628-849c177e76a1?q=80&w=300&auto=format&fit=crop",
            "SSMB29": "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?q=80&w=300&auto=format&fit=crop",
            "Vishwambhara": "https://images.unsplash.com/photo-1598899134739-24c46f58b8c0?q=80&w=300&auto=format&fit=crop",
            "Pushpa 2: The Rule": "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?q=80&w=300&auto=format&fit=crop",
            "OG": "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?q=80&w=300&auto=format&fit=crop"
        }

        print("🔧 Fixing broken movie posters...")
        for title, url in posters.items():
            try:
                self.supabase.table("tollypulse_movies").update({"poster_url": url}).eq("title", title).execute()
                print(f"✅ Fixed Poster: {title}")
            except Exception as e:
                print(f"❌ Failed: {title} - {e}")

        # Fix card previews (replacing mock YT IDs with real working placeholder images)
        print("🔧 Cleaning up broken card previews...")
        try:
            # Update cards that have 'mock' in the media_url
            self.supabase.table("tollypulse_cards").update({
                "media_url": "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?q=80&w=500&auto=format&fit=crop"
            }).ilike("media_url", "%mock%").execute()
            print("✅ Card previews updated to stable placeholders.")
        except Exception as e:
            print(f"❌ Failed cards cleanup: {e}")

if __name__ == "__main__":
    TollyPulseImageFixer().fix_all_images()
