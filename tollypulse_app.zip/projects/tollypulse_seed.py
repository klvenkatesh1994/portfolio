import os
from supabase import create_client, Client
from datetime import datetime

SUPABASE_URL = "https://qwcoxloagqjmlfzcugen.supabase.co"
SUPABASE_KEY = "sb_publishable_hvT_1U0NpUbueTuf122F_w_wM4pgmVk"

class TollyPulseSeeder:
    def __init__(self):
        self.supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

    def seed_initial_movies(self):
        movies = [
            {"title": "Game Changer", "status": "released", "director": "Shankar", "cast_members": ["Ram Charan", "Kiara Advani"]},
            {"title": "Spirit", "status": "pre-production", "director": "Sandeep Reddy Vanga", "cast_members": ["Prabhas"]},
            {"title": "Vishwambhara", "status": "filming", "director": "Vassishta", "cast_members": ["Chiranjeevi"]},
            {"title": "The Raja Saab", "status": "filming", "director": "Maruthi", "cast_members": ["Prabhas"]}
        ]
        
        print("🌱 Seeding initial movies...")
        for movie in movies:
            try:
                # Upsert based on title uniqueness
                res = self.supabase.table("tollypulse_movies").upsert(movie, on_conflict="title").execute()
                print(f"✅ Synced: {movie['title']}")
            except Exception as e:
                print(f"❌ Error seeding {movie['title']}: {e}")

    def add_sample_cards(self):
        # First, get movie IDs
        movies = self.supabase.table("tollypulse_movies").select("id, title").execute().data
        movie_map = {m['title']: m['id'] for m in movies}

        sample_cards = [
            {
                "movie_id": movie_map.get("Game Changer"),
                "card_type": "collection",
                "source_platform": "Trade Analyst",
                "headline": "Game Changer Worldwide Gross: ₹412.8 Cr",
                "content_body": "Strong hold on second week. USA gross continues to climb.",
                "sentiment_score": 0.9,
                "is_hot": True
            },
            {
                "movie_id": movie_map.get("Spirit"),
                "card_type": "gossip",
                "source_platform": "TollyPulse Insider",
                "headline": "Sandeep Vanga planning 120-day high-octane action schedule for Spirit.",
                "content_body": "Official news expected on Prabhas' next birthday.",
                "sentiment_score": 0.8,
                "is_hot": False
            }
        ]

        print("🎴 Adding sample cards to Firehose...")
        for card in sample_cards:
            if card["movie_id"]:
                try:
                    self.supabase.table("tollypulse_cards").insert(card).execute()
                    print(f"✅ Card added for {card['headline'][:30]}...")
                except Exception as e:
                    print(f"❌ Error adding card: {e}")

if __name__ == "__main__":
    seeder = TollyPulseSeeder()
    seeder.seed_initial_movies()
    seeder.add_sample_cards()
