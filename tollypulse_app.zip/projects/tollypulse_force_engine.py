import os
import requests
from bs4 import BeautifulSoup
from supabase import create_client, Client
from datetime import datetime

SUPABASE_URL = "https://qwcoxloagqjmlfzcugen.supabase.co"
SUPABASE_KEY = "sb_publishable_hvT_1U0NpUbueTuf122F_w_wM4pgmVk"

class TollyPulseForceEngine:
    def __init__(self):
        self.supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
        self.movies = self.supabase.table("tollypulse_movies").select("id, title").execute().data
        # Broaden sources to get more variety
        self.sources = [
            {"name": "123Telugu", "url": "https://www.123telugu.com/mnews"},
            {"name": "GreatAndhra", "url": "https://www.greatandhra.com/movies/news"},
            {"name": "Telugu360", "url": "https://www.telugu360.com/category/movies/"},
            {"name": "Mirchi9", "url": "https://www.mirchi9.com/category/movie-news/"}
        ]

    def run(self):
        print("🚀 Force Scaling Firehose Content...")
        for source in self.sources:
            try:
                res = requests.get(source['url'], timeout=15)
                soup = BeautifulSoup(res.content, 'html.parser')
                headlines = soup.find_all(['h2', 'h3', 'a'], limit=30)
                
                for h in headlines:
                    text = h.get_text(strip=True)
                    if len(text) < 15: continue
                    
                    # Try to match ANY movie from our 69 titles
                    for movie in self.movies:
                        if movie['title'].lower() in text.lower():
                            self.push_card(movie, text, source['name'])
                            break
            except Exception as e:
                print(f"Error {source['name']}: {e}")

    def push_card(self, movie, text, source):
        ctype = "news"
        if any(x in text.lower() for x in ["gossip", "rumor", "inside"]): ctype = "gossip"
        elif any(x in text.lower() for x in ["gross", "share", "collections"]): ctype = "collection"
        
        card = {
            "movie_id": movie['id'],
            "card_type": ctype,
            "source_platform": source,
            "headline": text,
            "sentiment_score": 0.7,
            "published_at": datetime.now().isoformat()
        }
        try:
            self.supabase.table("tollypulse_cards").insert(card).execute()
            print(f"✅ Added Card for: {movie['title']}")
        except:
            pass

if __name__ == "__main__":
    TollyPulseForceEngine().run()
