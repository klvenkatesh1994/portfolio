import os
import requests
from bs4 import BeautifulSoup
from supabase import create_client, Client
from datetime import datetime
import time

SUPABASE_URL = "https://qwcoxloagqjmlfzcugen.supabase.co"
SUPABASE_KEY = "sb_publishable_hvT_1U0NpUbueTuf122F_w_wM4pgmVk"

class TollyPulseFinalEngine:
    def __init__(self):
        self.supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
        self.movies = self.supabase.table("tollypulse_movies").select("id, title").execute().data
        self.sources = [
            {"name": "123Telugu", "url": "https://www.123telugu.com/mnews"},
            {"name": "GreatAndhra", "url": "https://www.greatandhra.com/movies/news"},
            {"name": "Telugu360", "url": "https://www.telugu360.com/category/movies/"}
        ]

    def scrape_all(self):
        all_news = []
        for source in self.sources:
            print(f"📡 Scraping {source['name']}...")
            try:
                res = requests.get(source['url'], timeout=15)
                soup = BeautifulSoup(res.content, 'html.parser')
                headlines = soup.find_all(['h2', 'h3'], limit=10)
                for h in headlines:
                    text = h.get_text(strip=True)
                    link = h.find('a')['href'] if h.find('a') else source['url']
                    if len(text) > 10:
                        all_news.append({"text": text, "url": link, "source": source['name']})
            except Exception as e:
                print(f"❌ Error scraping {source['name']}: {e}")
        return all_news

    def analyze_and_push(self, items):
        for item in items:
            text = item['text'].lower()
            target_movie = None
            
            # Simple Entity Matching (Brain extension logic)
            for m in self.movies:
                if m['title'].lower() in text:
                    target_movie = m
                    break
            
            if not target_movie: continue

            # Categorization Logic
            ctype = "news"
            if any(x in text for x in ["gossip", "rumor", "inside", "talk"]): ctype = "gossip"
            elif any(x in text for x in ["gross", "share", "collection", "box office"]): ctype = "collection"
            elif any(x in text for x in ["trailer", "teaser", "video", "song"]): ctype = "media"

            card = {
                "movie_id": target_movie['id'],
                "card_type": ctype,
                "source_platform": item['source'],
                "headline": item['text'],
                "source_url": item['url'],
                "sentiment_score": 0.85 if ctype == "collection" else 0.6,
                "published_at": datetime.now().isoformat()
            }

            try:
                self.supabase.table("tollypulse_cards").insert(card).execute()
                print(f"✅ Live Card: [{target_movie['title']}] {ctype}")
            except:
                pass

if __name__ == "__main__":
    engine = TollyPulseFinalEngine()
    news = engine.scrape_all()
    engine.analyze_and_push(news)
