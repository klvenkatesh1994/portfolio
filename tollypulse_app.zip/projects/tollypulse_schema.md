# TollyPulse / TFI Banisa - Database Schema (Draft v1)

## 1. Tables (PostgreSQL / Supabase)

### movies
- id (uuid, pk)
- title (text)
- release_date (date)
- cast (text[])
- crew (jsonb) -- {director: "", music: "", producer: ""}
- status (enum) -- 'pre-production', 'filming', 'ready', 'released'
- hype_score (int) -- Calculated based on aggregation

### cards (The "Firehose" Stream)
- id (uuid, pk)
- movie_id (uuid, fk)
- card_type (enum) -- 'collection', 'news', 'social', 'gossip', 'media', 'review'
- source_platform (text) -- 'twitter', 'youtube', 'greatandhra', '123telugu', etc.
- content (jsonb) -- {text: "", media_url: "", engagement: {}}
- sentiment_score (float) -- Derived via LLM/Sentiment Analysis
- published_at (timestamp)
- is_hot (boolean) -- For trending cards

### users
- id (uuid, pk)
- display_name (text)
- watchlist_movie_ids (uuid[])
- preferences (jsonb) -- {notifications_enabled: true, hidden_categories: []}

## 2. Caching Strategy (Redis / Upstash)
- **Key:** `firehose:active_movies` -> Sorted set of currently trending movie IDs.
- **Key:** `movie:feed:{movie_id}` -> List of latest 20 card IDs for instant horizontal scroll.
