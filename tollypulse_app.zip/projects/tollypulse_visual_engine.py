import os
import requests
import json
from supabase import create_client, Client
from datetime import datetime
import random

SUPABASE_URL = "https://qwcoxloagqjmlfzcugen.supabase.co"
SUPABASE_KEY = "sb_publishable_hvT_1U0NpUbueTuf122F_w_wM4pgmVk"

class TollyPulseVisualEngine:
    def __init__(self):
        self.supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
        self.movies = self.supabase.table("tollypulse_movies").select("id, title").execute().data

    def add_visual_cards(self):
        # Movie Map
        m_map = {m['title']: m['id'] for m in self.movies}
        
        visual_data = [
            # YouTube Media Previews
            {"movie": "The Raja Saab", "type": "media", "platform": "YouTube", 
             "head": "Official Motion Poster | Prabhas | Maruthi", 
             "img": "https://img.youtube.com/vi/mock1/maxresdefault.jpg"},
            
            {"movie": "Game Changer", "type": "media", "platform": "YouTube", 
             "head": "Jaragandi Song Full Video | Ram Charan", 
             "img": "https://img.youtube.com/vi/mock2/maxresdefault.jpg"},
            
            # X (Twitter) Social Previews
            {"movie": "SSMB29", "type": "social", "platform": "X (Twitter)", 
             "head": "#SSMB29 script is a globe-trotting adventure. 1000 days of Rajamouli vision coming!", 
             "img": "https://pbs.twimg.com/media/mock_ssmb29.jpg"},
            
            {"movie": "Spirit", "type": "social", "platform": "X (Twitter)", 
             "head": "Sandeep Vanga and Prabhas Mumbai schedule leaked stills! #Spirit", 
             "img": "https://pbs.twimg.com/media/mock_spirit.jpg"}
        ]

        print("🎬 Injecting visual preview cards...")
        for item in visual_data:
            m_id = m_map.get(item['movie'])
            if m_id:
                card = {
                    "movie_id": m_id,
                    "card_type": item['type'],
                    "source_platform": item['platform'],
                    "headline": item['head'],
                    "media_url": item['img'],
                    "sentiment_score": random.uniform(0.8, 0.99),
                    "published_at": datetime.now().isoformat()
                }
                self.supabase.table("tollypulse_cards").insert(card).execute()
                print(f"✅ Visual Card: {item['movie']}")

if __name__ == "__main__":
    TollyPulseVisualEngine().add_visual_cards()
