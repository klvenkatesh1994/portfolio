-- TollyPulse Database Schema (SQL for Supabase/PostgreSQL)

-- 1. Movies Table
CREATE TABLE IF NOT EXISTS tollypulse_movies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL UNIQUE,
    release_date DATE,
    director TEXT,
    cast_members TEXT[],
    status TEXT CHECK (status IN ('pre-production', 'filming', 'post-production', 'released')),
    hype_score INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Cards Table (The Firehose)
CREATE TABLE IF NOT EXISTS tollypulse_cards (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    movie_id UUID REFERENCES tollypulse_movies(id) ON DELETE CASCADE,
    card_type TEXT CHECK (card_type IN ('overview', 'collection', 'news', 'social', 'gossip', 'media', 'review')),
    source_platform TEXT, -- 'twitter', 'youtube', '123telugu', etc.
    headline TEXT NOT NULL,
    content_body TEXT,
    media_url TEXT,
    source_url TEXT,
    sentiment_score FLOAT DEFAULT 0.5,
    is_hot BOOLEAN DEFAULT FALSE,
    published_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Users/Profiles Table (For Personalization)
CREATE TABLE IF NOT EXISTS tollypulse_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id),
    display_name TEXT,
    watchlist UUID[], -- Array of movie IDs
    preferences JSONB DEFAULT '{}',
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Real-time for Cards
ALTER PUBLICATION supabase_realtime ADD TABLE tollypulse_cards;
