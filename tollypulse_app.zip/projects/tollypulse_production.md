# TOLLYPULSE - PRODUCTION STATUS 🌿

## Live Deployment
- **URL:** [klvenkatesh1994.github.io/portfolio/tollypulse.html](https://klvenkatesh1994.github.io/portfolio/tollypulse.html)
- **Status:** LIVE & SYNCED

## Engine Details
- **Script:** `projects/tollypulse_final_engine.py`
- **Schedule:** Every 1 Hour (Cron updated)
- **Sources:** 123Telugu, GreatAndhra, Telugu360
- **Database:** Supabase (Live)

## Features Implemented
- **Firehose UI:** Real-time horizontal carousels.
- **Auto-Aggregator:** Scrapes multiple Tollywood portals.
- **LLM-Categorizer:** Identifies movie, category (Gossip/Collection), and sentiment.
- **Ultra Seed:** Pre-loaded with 60+ major Tollywood projects for 2025-2026.
