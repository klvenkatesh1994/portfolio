import os
import json
from supabase import create_client, Client
from datetime import datetime

# TollyPulse Engine v2 - Now with LLM categorization
# This script uses the sessions_spawn/agent logic or direct completion 
# to categorize and clean the scraped data.

SUPABASE_URL = "https://qwcoxloagqjmlfzcugen.supabase.co"
SUPABASE_KEY = "sb_publishable_hvT_1U0NpUbueTuf122F_w_wM4pgmVk"

class TollyPulseEngineV2:
    def __init__(self):
        self.supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
        # Fetch active movies to help the LLM identify entities
        self.movies = self.supabase.table("tollypulse_movies").select("id, title").execute().data
        self.movie_titles = [m['title'] for m in self.movies]

    def analyze_content_with_llm(self, text):
        """
        In a real scenario, this would call Gemini.
        For this brain extension, I will simulate the structured output 
        I want the LLM to provide.
        """
        # PROMPT LOGIC: 
        # "Identify the movie from this list: {self.movie_titles}. 
        # Categorize as 'news', 'gossip', 'collection', 'media'.
        # Rate sentiment 0.0 to 1.0."
        
        # Simple heuristic simulation for now:
        category = "news"
        movie_id = None
        sentiment = 0.5

        lower_text = text.lower()
        if "gossip" in lower_text or "rumor" in lower_text or "talk" in lower_text:
            category = "gossip"
        elif "collection" in lower_text or "box office" in lower_text or "gross" in lower_text:
            category = "collection"
        elif "video" in lower_text or "trailer" in lower_text or "teaser" in lower_text:
            category = "media"

        for m in self.movies:
            if m['title'].lower() in lower_text:
                movie_id = m['id']
                break
        
        return {
            "movie_id": movie_id,
            "card_type": category,
            "sentiment": 0.8 if category == "collection" else 0.6
        }

    def process_and_upload(self, raw_items):
        print(f"🚀 Processing {len(raw_items)} items for TollyPulse Firehose...")
        for item in raw_items:
            analysis = self.analyze_content_with_llm(item['text'])
            
            if not analysis['movie_id']:
                # If LLM can't link to a movie, we might skip or put in 'General'
                continue

            card_data = {
                "movie_id": analysis['movie_id'],
                "card_type": analysis['card_type'],
                "source_platform": item['source'],
                "headline": item['text'],
                "source_url": item['url'],
                "sentiment_score": analysis['sentiment'],
                "published_at": datetime.now().isoformat()
            }

            try:
                self.supabase.table("tollypulse_cards").insert(card_data).execute()
                print(f"✅ Uploaded {analysis['card_type']} card for movie_id: {analysis['movie_id']}")
            except Exception as e:
                print(f"❌ Upload failed: {e}")

if __name__ == "__main__":
    # Test with sample data
    test_data = [
        {"source": "123telugu", "text": "Game Changer second week collections steady", "url": "http://example.com/1"},
        {"source": "greatandhra", "text": "Rumor: Spirit shooting delay due to script changes", "url": "http://example.com/2"}
    ]
    engine = TollyPulseEngineV2()
    engine.process_and_upload(test_data)
