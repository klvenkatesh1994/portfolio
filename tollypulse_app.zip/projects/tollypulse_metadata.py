import os
from supabase import create_client, Client

SUPABASE_URL = "https://qwcoxloagqjmlfzcugen.supabase.co"
SUPABASE_KEY = "sb_publishable_hvT_1U0NpUbueTuf122F_w_wM4pgmVk"

class TollyPulseMetadataSync:
    def __init__(self):
        self.supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

    def run(self):
        # We will use the 'preferences' or 'cast_members' or a JSON field 
        # to store the poster URL if the column wasn't added yet.
        # But wait, let's try a different trick: Use tollypulse_cards to store a 'poster' card type
        # Or better yet, I will update the code to use a fallback.
        print("Metadata sync standby.")

if __name__ == "__main__":
    TollyPulseMetadataSync().run()
