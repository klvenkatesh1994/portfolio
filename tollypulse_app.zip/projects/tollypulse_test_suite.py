import unittest
from supabase import create_client, Client
import requests
from bs4 import BeautifulSoup
from datetime import datetime

# Connection Details
SUPABASE_URL = "https://qwcoxloagqjmlfzcugen.supabase.co"
SUPABASE_KEY = "sb_publishable_hvT_1U0NpUbueTuf122F_w_wM4pgmVk"

class TestTollyPulseEngine(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # Initialize Supabase client
        cls.supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

    def test_database_connection(self):
        """Test if we can reach Supabase and tables exist."""
        try:
            movies = self.supabase.table("tollypulse_movies").select("id").limit(1).execute()
            self.assertIsNotNone(movies.data, "Failed to fetch movies data")
            print(f"✅ DB Connectivity: Movies table accessible.")
        except Exception as e:
            self.fail(f"DB Connectivity Failed: {e}")

    def test_movie_data_integrity(self):
        """Ensure we have populated movies in the DB."""
        movies = self.supabase.table("tollypulse_movies").select("title").execute()
        self.assertGreater(len(movies.data), 0, "No movies found in database")
        print(f"✅ Data Integrity: Found {len(movies.data)} movies.")

    def test_scraper_connectivity(self):
        """Test if the source websites are reachable."""
        sources = ["https://www.123telugu.com/mnews", "https://www.greatandhra.com/movies/news"]
        for url in sources:
            res = requests.get(url, timeout=10)
            self.assertEqual(res.status_code, 200, f"Source {url} is down")
        print(f"✅ Scraper Connectivity: All TFI portals are reachable.")

    def test_categorization_logic(self):
        """Test the logic that maps headlines to categories."""
        # Mock logic from engine
        def get_category(text):
            text = text.lower()
            if any(x in text for x in ["gossip", "rumor", "talk"]): return "gossip"
            if any(x in text for x in ["box office", "gross"]): return "collection"
            return "news"

        self.assertEqual(get_category("Game Changer Worldwide Gross"), "collection")
        self.assertEqual(get_category("Spirit Gossip: Update on shooting"), "gossip")
        self.assertEqual(get_category("SSMB29 script work starts"), "news")
        print("✅ Categorization Logic: Smart mapping works as expected.")

    def test_movie_matching(self):
        """Test if engine correctly identifies movie names in text."""
        movie_titles = ["Spirit", "Game Changer", "Vishwambhara"]
        headline = "New schedule for Spirit in Mumbai"
        
        match = None
        for title in movie_titles:
            if title.lower() in headline.lower():
                match = title
                break
        
        self.assertEqual(match, "Spirit")
        print("✅ Movie Matching: Entity identification is accurate.")

if __name__ == "__main__":
    unittest.main()
