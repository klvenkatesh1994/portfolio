import os
import requests
import json
from datetime import datetime

# Assuming the user might want to use Gemini for analysis
# This script focuses on YouTube Data API for TollyPulse media updates.

class TollyPulseYouTubeTracker:
    def __init__(self, api_key=None):
        self.api_key = api_key
        self.base_url = "https://www.googleapis.com/youtube/v3/search"

    def get_latest_trailers(self, movie_name):
        """
        Search for latest trailers/teasers/promotions for a movie.
        """
        if not self.api_key:
            print("Warning: YouTube API Key missing. Returning mock data.")
            return self._mock_data(movie_name)

        params = {
            'part': 'snippet',
            'q': f"{movie_name} official trailer teaser telugu",
            'type': 'video',
            'order': 'date',
            'maxResults': 5,
            'key': self.api_key
        }
        
        try:
            response = requests.get(self.base_url, params=params)
            data = response.json()
            videos = []
            for item in data.get('items', []):
                videos.append({
                    "title": item['snippet']['title'],
                    "video_id": item['id']['videoId'],
                    "published_at": item['snippet']['publishedAt'],
                    "thumbnail": item['snippet']['thumbnails']['high']['url']
                })
            return videos
        except Exception as e:
            print(f"Error fetching YouTube data: {e}")
            return []

    def _mock_data(self, movie_name):
        return [{
            "title": f"{movie_name} Official Teaser | Prabhas | Sandeep Vanga",
            "video_id": "mock_id_123",
            "published_at": datetime.now().isoformat(),
            "thumbnail": "https://img.youtube.com/vi/mock_id_123/hqdefault.jpg"
        }]

if __name__ == "__main__":
    tracker = TollyPulseYouTubeTracker()
    results = tracker.get_latest_trailers("Spirit")
    print(json.dumps(results, indent=2))
