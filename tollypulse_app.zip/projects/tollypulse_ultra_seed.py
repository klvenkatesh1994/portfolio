import os
from supabase import create_client, Client

SUPABASE_URL = "https://qwcoxloagqjmlfzcugen.supabase.co"
SUPABASE_KEY = "sb_publishable_hvT_1U0NpUbueTuf122F_w_wM4pgmVk"

class TollyPulseUltraSeeder:
    def __init__(self):
        self.supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

    def seed_all_movies(self):
        movies = [
            # Tier 1 & 2 - High Hype / Upcoming 2025-2026
            {"title": "Spirit", "status": "pre-production", "director": "Sandeep Reddy Vanga", "cast_members": ["Prabhas"]},
            {"title": "SSMB29", "status": "pre-production", "director": "SS Rajamouli", "cast_members": ["Mahesh Babu"]},
            {"title": "Dragon", "status": "filming", "director": "Prasanth Neel", "cast_members": ["NTR Jr"]},
            {"title": "The Raja Saab", "status": "filming", "director": "Maruthi", "cast_members": ["Prabhas"]},
            {"title": "Vishwambhara", "status": "post-production", "director": "Vassishta", "cast_members": ["Chiranjeevi"]},
            {"title": "Pushpa 3: The Rampage", "status": "pre-production", "director": "Sukumar", "cast_members": ["Allu Arjun"]},
            {"title": "Devara: Part 2", "status": "pre-production", "director": "Koratala Siva", "cast_members": ["NTR Jr"]},
            {"title": "Salaar: Part 2 – Shouryaanga Parvam", "status": "pre-production", "director": "Prasanth Neel", "cast_members": ["Prabhas"]},
            {"title": "Hari Hara Veera Mallu", "status": "post-production", "director": "Jyothi Krishna", "cast_members": ["Pawan Kalyan"]},
            {"title": "OG", "status": "post-production", "director": "Sujeeth", "cast_members": ["Pawan Kalyan"]},
            {"title": "Ustaad Bhagat Singh", "status": "filming", "director": "Harish Shankar", "cast_members": ["Pawan Kalyan"]},
            {"title": "Game Changer", "status": "released", "director": "Shankar", "cast_members": ["Ram Charan"]},
            {"title": "Sankranthiki Vasthunnam", "status": "released", "director": "Anil Ravipudi", "cast_members": ["Venkatesh"]},
            {"title": "Daaku Maharaaj", "status": "released", "director": "Bobby Kolli", "cast_members": ["Nandamuri Balakrishna"]},
            {"title": "Thandel", "status": "post-production", "director": "Chandoo Mondeti", "cast_members": ["Naga Chaitanya", "Sai Pallavi"]},
            {"title": "Mirai", "status": "filming", "director": "Karthik Ghattamaneni", "cast_members": ["Teja Sajja"]},
            {"title": "Kubera", "status": "filming", "director": "Sekhar Kammula", "cast_members": ["Dhanush", "Nagarjuna"]},
            {"title": "Goodachari 2", "status": "filming", "director": "Vinay Kumar", "cast_members": ["Adivi Sesh"]},
            {"title": "Daku Maharaj", "status": "released", "director": "Bobby", "cast_members": ["Balakrishna"]},
            {"title": "Swayambhu", "status": "filming", "director": "Bharat Krishnamachari", "cast_members": ["Nikhil Siddhartha"]},
            {"title": "The India House", "status": "filming", "director": "Ram Vamsi Krishna", "cast_members": ["Nikhil Siddhartha"]},
            {"title": "Odela 2", "status": "filming", "director": "Ashok Teja", "cast_members": ["Tamannaah Bhatia"]},
            {"title": "HIT 3", "status": "filming", "director": "Sailesh Kolanu", "cast_members": ["Nani"]},
            {"title": "Saripodhaa Sanivaaram", "status": "released", "director": "Vivek Athreya", "cast_members": ["Nani"]},
            {"title": "Mechanic Rocky", "status": "released", "director": "Ravi Teja Mullapudi", "cast_members": ["Vishwak Sen"]},
            {"title": "Laggam", "status": "released", "director": "Ramesh Cheppala", "cast_members": ["Sai Ronak"]},
            {"title": "Zebra", "status": "released", "director": "Eashvar Karthic", "cast_members": ["Satyadev", "Daali Dhananjaya"]},
            {"title": "Bachchala Malli", "status": "filming", "director": "Subbu", "cast_members": ["Allari Naresh"]},
            {"title": "Maa Nanna Gaming", "status": "filming", "director": "Nanda Kishore", "cast_members": ["Sudheer Babu"]},
            {"title": "Jatadhara", "status": "filming", "director": "Uday Shetty", "cast_members": ["Sudheer Babu"]},
            {"title": "Robinhood", "status": "filming", "director": "Venky Kudumula", "cast_members": ["Nithiin"]},
            {"title": "Tammudu", "status": "filming", "director": "Venu Sriram", "cast_members": ["Nithiin"]},
            {"title": "Revolver Rita", "status": "filming", "director": "K. Chandru", "cast_members": ["Keerthy Suresh"]},
            {"title": "Kannappa", "status": "post-production", "director": "Mukesh Kumar Singh", "cast_members": ["Vishnu Manchu", "Prabhas", "Akshay Kumar"]},
            {"title": "Manamey", "status": "released", "director": "Sriram Adittya", "cast_members": ["Sharwanand"]},
            {"title": "Sharwa37", "status": "filming", "director": "Ram Abbaraju", "cast_members": ["Sharwanand"]},
            {"title": "VD12", "status": "filming", "director": "Gowtam Tinnanuri", "cast_members": ["Vijay Deverakonda"]},
            {"title": "VD14", "status": "pre-production", "director": "Rahul Sankrityan", "cast_members": ["Vijay Deverakonda"]},
            {"title": "Tandel", "status": "post-production", "director": "Chandoo Mondeti", "cast_members": ["Naga Chaitanya"]},
            {"title": "NC23", "status": "filming", "director": "Karthik Thangavel", "cast_members": ["Naga Chaitanya"]},
            {"title": "RC16", "status": "pre-production", "director": "Buchi Babu Sana", "cast_members": ["Ram Charan", "Janhvi Kapoor"]},
            {"title": "NTR31", "status": "pre-production", "director": "Prasanth Neel", "cast_members": ["NTR Jr"]},
            {"title": "Animal Park", "status": "pre-production", "director": "Sandeep Reddy Vanga", "cast_members": ["Ranbir Kapoor"]},
            
            # Mid-Range & Small Scale
            {"title": "Appudo Ippudo Eppudo", "status": "released", "director": "Sudheer Varma", "cast_members": ["Nikhil Siddhartha"]},
            {"title": "Swag", "status": "released", "director": "Hasith Goli", "cast_members": ["Sree Vishnu"]},
            {"title": "Om Bheem Bush", "status": "released", "director": "Sree Harsha Konuganti", "cast_members": ["Sree Vishnu"]},
            {"title": "Gaami", "status": "released", "director": "Vidyadhar Kagita", "cast_members": ["Vishwak Sen"]},
            {"title": "Gangs of Godavari", "status": "released", "director": "Krishna Chaitanya", "cast_members": ["Vishwak Sen"]},
            {"title": "Tillu Square", "status": "released", "director": "Mallik Ram", "cast_members": ["Siddu Jonnalagadda"]},
            {"title": "Jack", "status": "filming", "director": "Bommarillu Bhaskar", "cast_members": ["Siddu Jonnalagadda"]},
            {"title": "Telusu Kada", "status": "filming", "director": "Neeraja Kona", "cast_members": ["Siddu Jonnalagadda"]},
            {"title": "Buddy", "status": "released", "director": "Sam Anton", "cast_members": ["Allu Sirish"]},
            {"title": "Committee Kurrollu", "status": "released", "director": "Yadu Vamsi", "cast_members": ["Newcomers"]},
            {"title": "Aay", "status": "released", "director": "Anji Kanchipallu", "cast_members": ["Narne Nithin"]},
            {"title": "35 Chinna Katha Kaadu", "status": "released", "director": "Nanda Kishore", "cast_members": ["Nivetha Thomas"]},
            {"title": "Mathu Vadalara 2", "status": "released", "director": "Ritesh Rana", "cast_members": ["Sri Simha", "Satya"]},
            {"title": "Janaka Aithe Ganaka", "status": "released", "director": "Sandeep Bandla", "cast_members": ["Suhas"]},
            {"title": "Ambajipeta Marriage Band", "status": "released", "director": "Dushyanth Katikaneni", "cast_members": ["Suhas"]},
            {"title": "Prasanna Vadanam", "status": "released", "director": "Arjun YK", "cast_members": ["Suhas"]},
            {"title": "Gorre Puranam", "status": "released", "director": "Bobby", "cast_members": ["Suhas"]}
        ]
        
        print(f"🌋 Initializing Ultra Seed for {len(movies)} movies...")
        for movie in movies:
            try:
                self.supabase.table("tollypulse_movies").upsert(movie, on_conflict="title").execute()
                print(f"✅ Synced: {movie['title']}")
            except Exception as e:
                print(f"❌ Error syncing {movie['title']}: {e}")

if __name__ == "__main__":
    seeder = TollyPulseUltraSeeder()
    seeder.seed_all_movies()
