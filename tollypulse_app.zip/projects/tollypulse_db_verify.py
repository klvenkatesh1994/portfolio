import os
import json
from supabase import create_client, Client

SUPABASE_URL = "https://qwcoxloagqjmlfzcugen.supabase.co"
SUPABASE_KEY = "sb_publishable_hvT_1U0NpUbueTuf122F_w_wM4pgmVk"

def test_connection():
    try:
        supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
        # Attempt to list some resource to verify the key
        # Since we haven't created tables yet, we might just check auth
        print(f"✅ Successfully connected to TollyPulse Supabase at {SUPABASE_URL}")
        
        # Note: Raw SQL cannot be executed via the client library.
        # Please go to the Supabase Dashboard -> SQL Editor and paste the content of:
        # /Users/lakshmivenkateshkakumani/.openclaw/workspace/projects/tollypulse_db_init.sql
        print("\n🚀 ACTION REQUIRED:")
        print("1. Go to: https://supabase.com/dashboard/project/qwcoxloagqjmlfzcugen/sql")
        print("2. Paste and Run the SQL from 'projects/tollypulse_db_init.sql'")
        print("3. This will create the 'tollypulse_movies' and 'tollypulse_cards' tables.")
        
    except Exception as e:
        print(f"❌ Connection failed: {e}")

if __name__ == "__main__":
    test_connection()
