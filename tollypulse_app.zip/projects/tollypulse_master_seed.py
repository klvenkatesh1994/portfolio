import os
from supabase import create_client, Client

SUPABASE_URL = "https://qwcoxloagqjmlfzcugen.supabase.co"
SUPABASE_KEY = "sb_publishable_hvT_1U0NpUbueTuf122F_w_wM4pgmVk"

class TollyPulseBigSeeder:
    def __init__(self):
        self.supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

    def seed_all_movies(self):
        # A comprehensive list of major Tollywood films (Released late 2024, 2025, and upcoming 2026)
        movies = [
            # 2026 / Upcoming High Hype
            {"title": "Spirit", "status": "pre-production", "director": "Sandeep Reddy Vanga", "cast_members": ["Prabhas"]},
            {"title": "SSMB29", "status": "pre-production", "director": "SS Rajamouli", "cast_members": ["Mahesh Babu"]},
            {"title": "Dragon", "status": "filming", "director": "Prasanth Neel", "cast_members": ["NTR Jr"]},
            {"title": "The Raja Saab", "status": "filming", "director": "Maruthi", "cast_members": ["Prabhas"]},
            {"title": "Vishwambhara", "status": "post-production", "director": "Vassishta", "cast_members": ["Chiranjeevi"]},
            {"title": "Pushpa 3: The Rampage", "status": "pre-production", "director": "Sukumar", "cast_members": ["Allu Arjun"]},
            
            # 2025 Big Releases
            {"title": "Game Changer", "status": "released", "director": "Shankar", "cast_members": ["Ram Charan", "Kiara Advani"]},
            {"title": "Hari Hara Veera Mallu", "status": "post-production", "director": "Krish / Jyothi Krishna", "cast_members": ["Pawan Kalyan"]},
            {"title": "OG (They Call Him OG)", "status": "post-production", "director": "Sujeeth", "cast_members": ["Pawan Kalyan"]},
            {"title": "Devara: Part 2", "status": "pre-production", "director": "Koratala Siva", "cast_members": ["NTR Jr", "Janhvi Kapoor"]},
            {"title": "Goodachari 2", "status": "filming", "director": "Vinay Kumar Sirigineedi", "cast_members": ["Adivi Sesh"]},
            {"title": "Kubera", "status": "filming", "director": "Sekhar Kammula", "cast_members": ["Dhanush", "Nagarjuna", "Rashmika Mandanna"]},
            {"title": "Sankranthiki Vasthunnam", "status": "released", "director": "Anil Ravipudi", "cast_members": ["Venkatesh"]},
            {"title": "Daaku Maharaaj", "status": "released", "director": "Bobby Kolli", "cast_members": ["Nandamuri Balakrishna"]},
            {"title": "Thandel", "status": "post-production", "director": "Chandoo Mondeti", "cast_members": ["Naga Chaitanya", "Sai Pallavi"]},
            {"title": "Mirai", "status": "filming", "director": "Karthik Ghattamaneni", "cast_members": ["Teja Sajja"]},
            
            # 2024 Major Hits (Still relevant for archives/collections)
            {"title": "Kalki 2898 AD", "status": "released", "director": "Nag Ashwin", "cast_members": ["Prabhas", "Amitabh Bachchan", "Kamal Haasan", "Deepika Padukone"]},
            {"title": "Devara: Part 1", "status": "released", "director": "Koratala Siva", "cast_members": ["NTR Jr", "Saif Ali Khan", "Janhvi Kapoor"]},
            {"title": "Pushpa 2: The Rule", "status": "released", "director": "Sukumar", "cast_members": ["Allu Arjun", "Rashmika Mandanna", "Fahadh Faasil"]},
            {"title": "Hanuman", "status": "released", "director": "Prasanth Varma", "cast_members": ["Teja Sajja"]},
            {"title": "Guntur Kaaram", "status": "released", "director": "Trivikram Srinivas", "cast_members": ["Mahesh Babu"]},
            {"title": "Salaar: Part 1 – Ceasefire", "status": "released", "director": "Prasanth Neel", "cast_members": ["Prabhas", "Prithviraj Sukumaran"]},
            {"title": "Lucky Baskhar", "status": "released", "director": "Venky Atluri", "cast_members": ["Dulquer Salmaan"]},
            {"title": "Matka", "status": "released", "director": "Karuna Kumar", "cast_members": ["Varun Tej"]}
        ]
        
        print(f"🚀 Initializing Master Seed for {len(movies)} movies...")
        for movie in movies:
            try:
                self.supabase.table("tollypulse_movies").upsert(movie, on_conflict="title").execute()
                print(f"✅ Synced: {movie['title']}")
            except Exception as e:
                print(f"❌ Error syncing {movie['title']}: {e}")

if __name__ == "__main__":
    seeder = TollyPulseBigSeeder()
    seeder.seed_all_movies()
