import os
import requests
import json
from supabase import create_client, Client
from datetime import datetime
import random

SUPABASE_URL = "https://qwcoxloagqjmlfzcugen.supabase.co"
SUPABASE_KEY = "sb_publishable_hvT_1U0NpUbueTuf122F_w_wM4pgmVk"

class TollyPulseMegaEngine:
    def __init__(self):
        self.supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
        self.movies = self.supabase.table("tollypulse_movies").select("id, title").execute().data

    def add_yt_cards(self):
        print("📺 Fetching YouTube Media Updates...")
        yt_data = [
            {"movie": "The Raja Saab", "head": "Official Motion Poster | Prabhas | Maruthi", "url": "https://youtu.be/mock1"},
            {"movie": "Game Changer", "head": "Jaragandi Song Full Video | Ram Charan", "url": "https://youtu.be/mock2"},
            {"movie": "Spirit", "head": "Sandeep Vanga Interview about Prabhas Role", "url": "https://youtu.be/mock3"},
            {"movie": "Vishwambhara", "head": "Grand VFX Making Video - Chiranjeevi", "url": "https://youtu.be/mock4"},
            {"movie": "Pushpa 2: The Rule", "head": "Allu Arjun Massive Entry Scene Leaked Clip", "url": "https://youtu.be/mock5"}
        ]
        self._push_batch(yt_data, "media", "YouTube")

    def add_x_cards(self):
        print("🐦 Fetching X (Twitter) Fan Sentiment...")
        x_data = [
            {"movie": "SSMB29", "head": "#SSMB29 script is a globe-trotting adventure. 1000 days of Rajamouli vision coming!", "url": "https://x.com/mock1"},
            {"movie": "Game Changer", "head": "Nizam advance bookings opening with a bang! #RamCharanMania", "url": "https://x.com/mock2"},
            {"movie": "The Raja Saab", "head": "Prabhas look in the new schedule is just 🔥. Vintage Darling is back.", "url": "https://x.com/mock3"},
            {"movie": "Spirit", "head": "Rumors about police academy set in Mumbai are true. #SpiritUpdate", "url": "https://x.com/mock4"},
            {"movie": "OG", "head": "Hungry Cheetah arriving soon. Dubbing almost done. #PawanKalyan", "url": "https://x.com/mock5"}
        ]
        self._push_batch(x_data, "social", "X (Twitter)")

    def _push_batch(self, data, ctype, platform):
        movie_map = {m['title']: m['id'] for m in self.movies}
        for item in data:
            m_id = movie_map.get(item['movie'])
            if m_id:
                card = {
                    "movie_id": m_id,
                    "card_type": ctype,
                    "source_platform": platform,
                    "headline": item['head'],
                    "source_url": item['url'],
                    "sentiment_score": random.uniform(0.7, 0.98),
                    "published_at": datetime.now().isoformat()
                }
                try:
                    self.supabase.table("tollypulse_cards").insert(card).execute()
                    print(f"✅ Added {platform} card for {item['movie']}")
                except: pass

if __name__ == "__main__":
    engine = TollyPulseMegaEngine()
    engine.add_yt_cards()
    engine.add_x_cards()
