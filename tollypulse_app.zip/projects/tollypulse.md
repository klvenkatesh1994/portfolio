# TollyPulse - Project Documentation 🌿

## 1. Vision
The ultimate "Firehose" dashboard for Tollywood fans. Real-time updates, sentiment-tracked "Talk," and upcoming movie trackers.

## 2. Branding
- **Name:** TollyPulse
- **Alternative:** TFI Banisa
- **Naming Convention:** `tollypulse_*` (e.g., `tollypulse_api`, `tollypulse_db`)

## 3. Key Feature: Upcoming Movies Tracker
- **Pre-Production:** Casting rumors, music sittings, script locks.
- **Production:** Shooting schedules, location leaks, leaked stills (categorized as Gossip/Media).
- **Post-Production:** Dubbing updates, Censor talk, Runtime info.
- **Release Countdown:** Trailer drops, Ticket open alerts, US Premieres.

## 4. LLM Role in Upcoming Info
- **Hype Meter:** Analyzing "Leaked" info vs "Official" info to score how excited the fans are.
- **Relationship Mapping:** Automatically linking cast/crew across different upcoming projects.
