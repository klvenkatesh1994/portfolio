import requests
import json

SUPABASE_URL = "https://qwcoxloagqjmlfzcugen.supabase.co"
SUPABASE_KEY = "sb_publishable_hvT_1U0NpUbueTuf122F_w_wM4pgmVk"

def run_sql(sql_query):
    """
    Supabase doesn't have a direct REST API for raw SQL for security reasons
    (usually done via the dashboard SQL editor).
    However, we can try to initialize the schema by checking table existence via REST.
    """
    headers = {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json",
        "Prefer": "return=representation"
    }
    
    # Testing connection by fetching tables (if any exist)
    try:
        response = requests.get(f"{SUPABASE_URL}/rest/v1/", headers=headers)
        if response.status_code == 200:
            print("Successfully connected to TollyPulse Supabase!")
            return response.json()
        else:
            print(f"Connection failed: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        print(f"Error: {e}")
        return None

if __name__ == "__main__":
    run_sql("SELECT 1")
